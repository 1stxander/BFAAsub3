package com.sesingkat.githubuserappsub

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USER = "extra_user"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val user = intent.getParcelableExtra(EXTRA_USER) as User

        iv_avatar_received.setImageResource(user.avatar)
        tv_username_received.text = "Username : ${user.username}"
        tv_name_received.text = "Name : ${user.name}"
        tv_company_received.text = "Company : ${user.company}"
        tv_location_received.text = "Location : ${user.location}"
        tv_repository_received.text = "Repository : ${user.repository}"
        tv_followers_received.text = "Followers : ${user.followers}"
        tv_following_received.text = "Following : ${user.following}"
    }
}